package exercises

import groovy.json.JsonSlurper
import groovy.json.JsonOutput

	

//reading the JSON file and parse it to text
def jsonSlurper = new JsonSlurper()
def file = new File('src/main/resources/prize_list.json')
def winners = jsonSlurper.parseText(file.text) as ArrayList

//println(JsonOutput.prettyPrint(JsonOutput.toJson(winners)))
/*
	Select winners(Fullname+Country+Gender+Prize+Year)
	who won prize in medicine and from France between 1980-2010
	sort by year in descending order
	groupBy gender
*/


/*
 * APPLY QUERY
 * 
 * 
 * There are two options to do the query:
 * 
 * WAY 1:
 * simply access all sub-arrayList elements by their index [] and apply the whole query 
 * 
 * WAY 2:
 * create a function to unpack all sub-arrayLists to become a flat arrayList (key:value)
 * so we can access every value with their key
 */

def projection = {[
	Fullname : it.firstname +" "+ it.surname,
	From : it.bornCountry,
	Gender: it.gender,
	Prize :  it.prizes.category,
	Year: it.prizes.year,
  ]}


/*
 // WAY 1:

def start = System.currentTimeMillis()

result = winners.findAll{it.bornCountry =="France" && it.prizes[0].category =="medicine" && it.prizes[0].year >= "1980"}
				.collect {projection(it)}
				.sort{it.Year}.reverse()
				.groupBy { it.Gender }
				
println(JsonOutput.prettyPrint(JsonOutput.toJson(result)))
println ""
println""

def end = System.currentTimeMillis()
def elapsedtime = end - start
println("   Time execution for query is: " + elapsedtime + " ms")

*/


 /*
 // WAY 2:
 
 

result = winners.findAll { it.bornCountry == "France" }
				.collectNested { projection(it) }
				.sort { it.Year }.reverse()
				
def flatter(oldarray) 
{
	def winArray1 = []
	
	for(win in oldarray) {
		for(prize in win.Prize) {
			def copy1 = win.clone()
			copy1.Prize = prize
			winArray1 << copy1}}
	
	//println(JsonOutput.prettyPrint(JsonOutput.toJson(winArray1)))
	
	
	def winArray2 = []
	
	for(win in winArray1) {
		for(year in win.Year) {
			def copy2 = win
			copy2.Year = year
			winArray2 << copy2
					
		}
	}
	//println(JsonOutput.prettyPrint(JsonOutput.toJson(winArray2)))
	return winArray2
}				

//clone() difference
//println(JsonOutput.prettyPrint(JsonOutput.toJson(result)))
finalArrayList = flatter(result)
//println(JsonOutput.prettyPrint(JsonOutput.toJson(result)))

// Now we can access the array as a key:value arrayList and applying the rest of filters plus grouping them
finalResult = finalArrayList.findAll { it.Prize =='medicine' && it.Year <="2010" && it.Year>="1980"}
					   .groupBy { it.Gender }

					  
println(JsonOutput.prettyPrint(JsonOutput.toJson(finalResult)))

*/
